/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javapoemain;

import java.util.regex.Pattern;

public class Registration {
    // User information
    private String firstName;
    private String lastName;
    private String userName;
    private String password;
    private String cellPhoneNumber;

    // Stores whether the login was successful
    private boolean loginSuccessful;

    // Constructor (must match the class name exactly, including capital R)
    public Registration(String firstName, String lastName, String userName, String password, String cellPhoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
    }

    // Username must contain an underscore and be at least 5 characters long
    public boolean checkUserName() {
        return userName != null && userName.contains("_") && userName.length() >= 5;
    }

    // Password must be 8+ characters with a capital letter, a number and a special character
    public boolean checkPasswordComplexity() {
        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasCapitalLetter = false;
        boolean hasNumber = false;
        boolean hasSpecialCharacter = false;

        for (int i = 0; i < password.length(); i++) {
            char character = password.charAt(i);

            if (Character.isUpperCase(character)) {
                hasCapitalLetter = true;
            }
            if (Character.isDigit(character)) {
                hasNumber = true;
            }
            if (!Character.isLetterOrDigit(character)) {
                hasSpecialCharacter = true;
            }
        }
        return hasCapitalLetter && hasNumber && hasSpecialCharacter;
    }

    // Cell phone number must start with +27 followed by 9 digits
    public boolean checkCellPhoneNumber() {
        if (cellPhoneNumber == null) {
            return false;
        }
        String regex = "^\\+27[0-9]{9}$";
        return Pattern.matches(regex, cellPhoneNumber);
    }

    // Registration method
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is at least 5 characters long";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that your password is at least 8 characters long and contains a capital letter, a number, and a special character";
        }
        if (!checkCellPhoneNumber()) {
            return "Cell phone number is not correctly formatted; please ensure that it starts with +27 followed by 9 digits";
        }
        return "Registration successful!";
    }

    // Login method (null-safe)
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        loginSuccessful = userName != null && password != null
                && userName.equals(enteredUsername)
                && password.equals(enteredPassword);
        return loginSuccessful;
    }

    public static void main(String[] args) {
        Registration user = new Registration("Thabo", "Mokoena", "thabo_m", "Passw0rd!", "+27821234567");

        System.out.println(user.registerUser());
        System.out.println("Login result: " + user.loginUser("thabo_m", "Passw0rd!"));
    }
}