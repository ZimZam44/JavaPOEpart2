/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javapoemain;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * QuickChat - combined program (Main + Registration + Login + Message).
 * Requires the Gson library on the classpath.
 */
public class JavaPOEMain {

    private static Registration registeredUser = null;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Restore counters from saved files so hashes keep counting correctly
        Message.sentCount = Message.loadSentMessages().size();
        Message.messageCount = Message.loadStoredMessages().size();

        System.out.println("=====================");
        System.out.println("WELCOME TO QUICKCHAT");
        System.out.println("=====================");

        boolean programOn = true;
        while (programOn) {
            System.out.println("\n---------MAIN MENU-------------");
            System.out.println("| 1. Register New Account   |");
            System.out.println("| 2. Login                  |");
            System.out.println("| 3. Exit                   |");
            System.out.println("-------------------------------");
            int choice = readInt(input, "Enter your choice: ");

            switch (choice) {
                case 1:
                    doRegister(input);
                    break;
                case 2:
                    doLogin(input);
                    break;
                case 3:
                    System.out.println("\nThanks for using QuickChat. Goodbye!");
                    programOn = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please enter 1, 2 or 3.");
            }
        }
        input.close();
    }

    // Reads an integer safely; keeps asking until one is entered
    private static int readInt(Scanner input, String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = input.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number.");
            }
        }
    }

    private static String readLine(Scanner input, String prompt) {
        System.out.print(prompt);
        return input.nextLine().trim();
    }

    // Registration
    private static void doRegister(Scanner input) {
        String firstName = readLine(input, "First name: ");
        String lastName = readLine(input, "Last name: ");
        String userName = readLine(input, "Username (needs _ and 5+ characters): ");
        String password = readLine(input, "Password (8+ chars, capital, number, special): ");
        String cell = readLine(input, "Cell number (+27 followed by 9 digits): ");

        Registration attempt = new Registration(firstName, lastName, userName, password, cell);
        String result = attempt.registerUser();
        System.out.println(result);

        if (result.equals("Registration successful!")) {
            registeredUser = attempt;
        }
    }

    // Login - the message menu is only reachable after a successful login
    private static void doLogin(Scanner input) {
        if (registeredUser == null) {
            System.out.println("No account registered yet. Please register first.");
            return;
        }

        String userName = readLine(input, "Username: ");
        String password = readLine(input, "Password: ");

        LoginClass login = new LoginClass(registeredUser);
        if (login.attemptLogin(userName, password)) {
            messageMenu(input);
        }
    }

    // Menu shown only to logged-in users
    private static void messageMenu(Scanner input) {
        boolean loggedIn = true;
        while (loggedIn) {
            System.out.println("\n---------MESSAGE MENU----------");
            System.out.println("| 1. Send Messages            |");
            System.out.println("| 2. Show recently sent       |");
            System.out.println("| 3. Quit                     |");
            System.out.println("-------------------------------");
            int choice = readInt(input, "Enter your choice: ");

            switch (choice) {
                case 1:
                    sendMessageFlow(input);
                    break;
                case 2:
                    System.out.println("Coming soon.");
                    break;
                case 3:
                    System.out.println("Logged out. Returning to main menu.");
                    loggedIn = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please enter 1, 2 or 3.");
            }
        }
    }

    private static void sendMessageFlow(Scanner input) {
        String recipient = readLine(input, "Recipient number (+27 followed by 9 digits): ");
        System.out.println(Message.checkRecipientCell(recipient));
        if (!Message.isValidRecipient(recipient)) {
            return;
        }

        String content = readLine(input, "Message (max 250 characters): ");
        if (content.isEmpty()) {
            System.out.println("Message cannot be empty.");
            return;
        }
        String lengthResult = Message.checkMessageLength(content);
        System.out.println(lengthResult);
        if (content.length() > 250) {
            return;
        }

        Message msg = new Message(recipient, content);
        System.out.println("\n1) Send   2) Store   3) Discard");
        int action = readInt(input, "Choose: ");

        String result;
        switch (action) {
            case 1:
                result = msg.SentMessage("Send");
                break;
            case 2:
                result = msg.SentMessage("Store");
                break;
            case 3:
                result = msg.SentMessage("Discard");
                break;
            default:
                System.out.println("Invalid choice. Message not processed.");
                return;
        }
        System.out.println(result);
        if (action == 3) {
            String press = readLine(input, "");
            if (press.equals("0")) {
                System.out.println("Message deleted.");
            }
        } else {
            System.out.println(msg.messageIDGenerated());
            msg.displayFullMessage();
        }
    }
}

// ============================ Registration ============================
class Registration {
    private String firstName;
    private String lastName;
    private String userName;
    private String password;
    private String cellPhoneNumber;
    private boolean loginSuccessful;

    public Registration(String firstName, String lastName, String userName,
                        String password, String cellPhoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
    }

    // Username must contain an underscore and be at least 5 characters long
    public boolean checkUserName() {
        return userName != null && userName.contains("_") && userName.length() >= 5;
    }

    // Password: 8+ characters, capital letter, number, special character
    public boolean checkPasswordComplexity() {
        if (password == null || password.length() < 8) {
            return false;
        }
        boolean hasCapital = false, hasNumber = false, hasSpecial = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasCapital = true;
            if (Character.isDigit(c)) hasNumber = true;
            if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }
        return hasCapital && hasNumber && hasSpecial;
    }

    // Cell number must be +27 followed by 9 digits
    public boolean checkCellPhoneNumber() {
        return cellPhoneNumber != null
                && Pattern.matches("^\\+27[0-9]{9}$", cellPhoneNumber);
    }

    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is at least 5 characters long";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that your password is at least 8 characters long and contains a capital letter, a number, and a special character";
        }
        if (!checkCellPhoneNumber()) {
            return "Cell phone number is not correctly formatted; please ensure that it starts with +27 followed by 9 digits";
        }
        return "Registration successful!";
    }

    public boolean loginUser(String enteredUsername, String enteredPassword) {
        loginSuccessful = userName != null && password != null
                && userName.equals(enteredUsername)
                && password.equals(enteredPassword);
        return loginSuccessful;
    }

    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
}

// ============================== Login ==============================
class LoginClass {
    private Registration registeredUser;

    public LoginClass(Registration registeredUser) {
        this.registeredUser = registeredUser;
    }

    public boolean attemptLogin(String enteredUsername, String enteredPassword) {
        if (registeredUser == null) {
            System.out.println("No registered user is linked to this login.");
            return false;
        }
        boolean success = registeredUser.loginUser(enteredUsername, enteredPassword);
        if (success) {
            System.out.println("Login successful. Welcome back, "
                    + registeredUser.getFirstName() + " " + registeredUser.getLastName() + "!");
        } else {
            System.out.println("Login failed. Incorrect username or password.");
        }
        return success;
    }
}

// ============================= Message =============================
class Message {
    public static int messageCount = 0;
    public static int sentCount = 0;

    private String messageID;
    private String recipientNumber;
    private String messageContent;
    private String messageHash;
    private String status;

    private static final String STORED_FILE = "stored_messages.json";
    private static final String SENT_FILE = "sent_messages.json";

    // Set to false in unit tests so nothing is written to the JSON files
    public static boolean saveToFile = true;

    public Message() {
        this("", "");
    }

    public Message(String recipientNumber, String messageContent) {
        this(null, recipientNumber, messageContent);
    }

    // Lets tests supply a known ID (null = auto-generate one)
    public Message(String messageID, String recipientNumber, String messageContent) {
        this.messageID = messageID != null ? messageID : generateMessageID();
        this.recipientNumber = recipientNumber != null ? recipientNumber : "";
        this.messageContent = messageContent != null ? messageContent : "";
        this.status = "Stored";
        this.messageHash = createMessageHash(this.messageID, messageCount, this.messageContent);
    }

    public static boolean isValidRecipient(String number) {
        return number != null && Pattern.matches("^\\+27[0-9]{9}$", number);
    }

    // 10-digit message ID
    private String generateMessageID() {
        SecureRandom random = new SecureRandom();
        StringBuilder sb = new StringBuilder(10);
        for (int i = 0; i < 10; i++) sb.append(random.nextInt(10));
        return sb.toString();
    }

    // Hash = first 2 chars of ID : message number : FIRSTWORD + LASTWORD (letters/digits only)
    public static String createMessageHash(String id, int messageNumber, String content) {
        String idPart = (id != null && id.length() >= 2) ? id.substring(0, 2) : "";
        String firstWord = "", lastWord = "";
        if (content != null && !content.trim().isEmpty()) {
            String[] words = content.trim().split("\\s+");
            firstWord = words[0].replaceAll("[^A-Za-z0-9]", "").toUpperCase();
            lastWord = words[words.length - 1].replaceAll("[^A-Za-z0-9]", "").toUpperCase();
        }
        return idPart + ":" + messageNumber + ":" + firstWord + lastWord;
    }

    // Message must not be more than 250 characters
    public static String checkMessageLength(String content) {
        int length = content == null ? 0 : content.length();
        if (length <= 250) {
            return "Message ready to send.";
        }
        return "Message exceeds 250 characters by " + (length - 250)
                + "; please reduce the size.";
    }

    // Reuses the same +27 rule as Registration
    public static String checkRecipientCell(String number) {
        if (isValidRecipient(number)) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    public String messageIDGenerated() {
        return "Message ID generated: " + messageID;
    }

    public static int returnTotalMessages() {
        return sentCount;
    }

    public void displayFullMessage() {
        System.out.println("ID: " + messageID);
        System.out.println("Recipient: " + recipientNumber);
        System.out.println("Content: " + messageContent);
        System.out.println("Hash: " + messageHash);
        System.out.println("Status: " + status);
    }

    public String getMessageID() { return messageID; }
    public String getRecipientNumber() { return recipientNumber; }
    public String getMessageContent() { return messageContent; }
    public String getMessageHash() { return messageHash; }
    public String getStatus() { return status; }

    public static void saveMessages(List<Message> messages, String filename) {
        Gson gson = new Gson();
        try (FileWriter writer = new FileWriter(filename)) {
            writer.write(gson.toJson(messages));
        } catch (IOException e) {
            throw new RuntimeException("Could not save messages to " + filename, e);
        }
    }

    public static List<Message> loadMessages(String filename) {
        Gson gson = new Gson();
        try (FileReader reader = new FileReader(filename)) {
            Type type = new TypeToken<List<Message>>() {}.getType();
            List<Message> messages = gson.fromJson(reader, type);
            return messages != null ? messages : new ArrayList<>();
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    public static List<Message> loadStoredMessages() { return loadMessages(STORED_FILE); }
    public static List<Message> loadSentMessages() { return loadMessages(SENT_FILE); }
    public static void saveStoredMessages(List<Message> m) { saveMessages(m, STORED_FILE); }
    public static void saveSentMessages(List<Message> m) { saveMessages(m, SENT_FILE); }

    // Send / Store / Discard
    public String SentMessage(String action) {
        if (action == null) return "invalid.";
        if (action.equalsIgnoreCase("Send")) {
            this.status = "Sent";
            this.messageHash = createMessageHash(messageID, sentCount, messageContent);
            sentCount++;
            if (saveToFile) {
                List<Message> sent = loadSentMessages();
                sent.add(this);
                saveSentMessages(sent);
            }
            return "Message successfully sent.";
        } else if (action.equalsIgnoreCase("Store")) {
            this.status = "Stored";
            this.messageHash = createMessageHash(messageID, messageCount, messageContent);
            messageCount++;
            if (saveToFile) {
                List<Message> stored = loadStoredMessages();
                stored.add(this);
                saveStoredMessages(stored);
            }
            return "Message successfully stored.";
        } else if (action.equalsIgnoreCase("Discard")) {
            this.status = "Discarded"; // discarded messages are not saved anywhere
            return "Press 0 to delete the message.";
        }
        return "invalid.";
    }

    public static boolean checkMessageID(String id) {
        if (id == null || id.isEmpty()) return false;
        for (Message m : loadStoredMessages()) if (m.getMessageID().equals(id)) return true;
        for (Message m : loadSentMessages()) if (m.getMessageID().equals(id)) return true;
        return false;
    }

    public static void deleteMessageByID(String id) {
        if (id == null || id.isEmpty()) {
            System.out.println("Invalid ID.");
            return;
        }
        List<Message> stored = loadStoredMessages();
        for (int i = 0; i < stored.size(); i++) {
            if (stored.get(i).getMessageID().equals(id)) {
                stored.remove(i);
                saveStoredMessages(stored);
                System.out.println("Deleted stored message ID " + id);
                return;
            }
        }
        List<Message> sent = loadSentMessages();
        for (int i = 0; i < sent.size(); i++) {
            if (sent.get(i).getMessageID().equals(id)) {
                sent.remove(i);
                saveSentMessages(sent);
                System.out.println("Deleted sent message ID " + id);
                return;
            }
        }
        System.out.println("No message found with ID " + id);
    }
}