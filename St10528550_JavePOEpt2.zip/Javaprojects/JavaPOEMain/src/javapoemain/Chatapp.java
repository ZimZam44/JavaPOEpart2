/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javapoemain;

import java.security.SecureRandom;
import java.util.ArrayList; 
import java.util.List;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Comparator;

public class Chatapp {
    public static int messageCount = 0;
    public static int sentCount = 0; 
    
    private String messageID;
    private String recipientNumber; 
    private String messageContent; 
    private String messageHash; 
    private String status;
    
    //seperate filenames for sent and stored messages
    private static final String STORED_FILE = "stored _messages.json"; 
    private static final String SENT_FILE = "sent_messages.json";
    
    //constructors
    public Chatapp() {
        messageID = generateMessageID();
        status = "Stored"; 
        messageHash = generateDisplayHash(); 
    }
    
    //constructor 
    public Chatapp (String recipientNumber, String messageContent) {
        this.messageID = generateMessageID(); 
        this.recipientNumber = recipientNumber != null ? recipientNumber : "";
        this.messageContent = messageContent != null ? messageContent : "";
        this.messageHash = generateDisplayHash();
        this.status = "Stored";
    }
    
    //generate ID
    private String generateMessageID() {
        SecureRandom random = new SecureRandom();
        StringBuilder sb = new StringBuilder(10); 
        for (int i = 0; i<10; i++) sb.append((char)(random.nextInt(26)+'a'));
        return sb.toString();
    }
    //generate hash 
    private String generateDisplayHash() {
        String idPart = messageID.substring(0,2); 
        String firstWord = "", lastWord = "";
        if (messageContent!=null && !messageContent.trim().isEmpty() ) {
            String[] words = messageContent.trim().split("\\s+");
            firstWord = words[0].toUpperCase();
            lastWord = words[words.length-1].toUpperCase();
        }
        int sequenceNumber = (status!=null && status.equals("Sent")) ? sentCount : messageCount+1; 
        return idPart+":"+sequenceNumber+":"+firstWord+lastWord; 
    }
    
    //Display 
    public void displayFullMessage() {
        System.out.println("ID: "+messageID);
        System.out.println("Recipient: "+recipientNumber);
        System.out.println("Content: "+messageContent);
        System.out.println("Hash: "+messageHash);
        System.out.println("Status: "+status);
    }
    
    //recievers 
    public String getMessageID(){return messageID;}
    public String getRecipientNumber(){return recipientNumber;} 
    public String getMessagecontent() {return messageContent;}
    public String getMessageHash() {return messageHash;}
    public String getStatus() {return status;}
    
    // save 
    public static void saveMessages(List<Message> messages, String filename) {
        Gson gson= new Gson (); 
        String json = gson.toJson(messages);
        try(FileWriter write=new FileWriter(filename))(writer.write(json);)catch(IOException e)(throw new RuntimeExcept:); 
    }
        
     public static List<Message> loadMessages(String filename){
         Gson gson=new Gson();
         try(FileReader reader=new FileReader(filename)){
             Type type=new TypeToken<List<Message>>(){}.getType();
             List<Message> messages=gson.fromJson(reader,type);
             return messages!=null? messages:new Arraylist<>();
         }catch (IOException e){return new ArrayList<>();}
         
     }
     
     public static List<Message> loadStoredMessages(){return loadMessages(STORED_FILE);} 
     public static List<Message> loadsentMessages(){return loadMessages(SENT_FILE);}
     public static void saveStoredMessages(List<Message> messages){saveMessages(messages,STORED_FILE);}
     public static void saveSentMessages(List<Messages> messages) {saveMessages(messages,SENT_FILE);} 
     
     //IF statements 
     public String SentMessage(String action){
         if(action.equalsIgnoreCase("Send")){
             this.status="Sent";
             sentCount++;
             this.messageHash= generateDisplayHash();
             saveCurrentMessageToSent(); 
             return "Message was sent."; 
         }else if (action.equalsIgnoreCase("Store")){
             this.status="Stored";
             messageCount++;
             this.messageHash= generateDisplayHash();
             saveCurrentMessageToStored();
             return "Message succesfully stored.";
         }else if (action.equalsIgnoreCase("Discard")){
         this.status= "Discarded";
             saveCurrentMessageToStored();
             return "Message discarded.";
         }else return "invalid.";    
             
    }
     private void saveCurrentMessageToSent(){
         List<Message> sent=loadSentMessages();
         sent.add(this);
         saveSentMessages(sent);
     }
     
     private void saveCurrentMessegeToStored(){
         List<Message> stored=loadStoredMessages();
         stored.add(this);
         saveStoredMessages(stored);
     }   

//check Id 
     public static boolean checkMessageID(String id){
         if(id==null||id.isEmpty())return false;
         for(Message m:loadMessages(STORED_FILE)) if(m.getMessageID().equals(id)) return true;
         for(Message m:loadMessages(SENT_FILE)) if(m.getMessageID().equals(id)) return true; 
         return false; 
     }
     
// delete By ID
     public static void deleteMessageByID(string id){
         if(id==null||id.isEmpty()){System.out.println("invalid ID.");return;}
         List<Message> stored+loadMessages(STORED_FILE);
         for(int i=0; i<stored.size();i++){
             if(stored.get(i).getmessageID().equals(id)){
                 stored.remove(i);saveMessages(stored,STORED_FILE);
                 System.out.println("Deleted stored message ID"+id);return;
             }
         }
         List<Message> sent=loadMessages(SENT_FILE);
         for(int i=0;i<sent.size();i++){
             if(sent.get(i).getMessageID().equals(id)){
                 sent.remove(i);saveMessages(sent,SENT_FILE);
                 System.out.println("deleted sent message ID"+id);return;
             }
         }
     } 
     }
     

     
     

  
