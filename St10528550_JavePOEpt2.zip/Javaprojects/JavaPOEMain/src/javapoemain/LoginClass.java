/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javapoemain;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class LoginClass {

    private Registration registeredUser;

    // Link this login class to an existing registration
    // (constructor name must match the class name: LoginClass)
    public LoginClass(Registration registeredUser) {
        this.registeredUser = registeredUser;
    }

    // Attempt to log in using the linked registration's credentials
    public boolean attemptLogin(String enteredUsername, String enteredPassword) {
        if (registeredUser == null) {
            System.out.println("No registered user is linked to this login.");
            return false;
        }

        boolean success = registeredUser.loginUser(enteredUsername, enteredPassword);

        if (success) {
            System.out.println("Login successful. Welcome back!");
        } else {
            System.out.println("Login failed. Incorrect username or password.");
        }

        return success;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create and register a user first
        Registration newUser = new Registration("Thabo", "Mokoena", "thabo_m", "Passw0rd!", "+27821234567");
        String registrationResult = newUser.registerUser();
        System.out.println(registrationResult);

        // Only proceed to login if registration was successful
        if (registrationResult.equals("Registration successful!")) {
            LoginClass loginSystem = new LoginClass(newUser);

            System.out.print("Enter username: ");
            String enteredUsername = scanner.nextLine();

            System.out.print("Enter password: ");
            String enteredPassword = scanner.nextLine();

            loginSystem.attemptLogin(enteredUsername, enteredPassword);
        }

        scanner.close();
    }
}
 
