package javapoemain;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

public class MessageTest {

    // Test data from the assignment
    private static final String MSG1_RECIPIENT = "+27718693002";
    private static final String MSG1_TEXT = "Hi Mike, can you join us for dinner tonight?";
    private static final String MSG2_RECIPIENT = "08575975889";
    private static final String MSG2_TEXT = "Hi Keegan, did you receive the payment?";

    @Before
    public void setUp() {
        // Start every test from a clean state and never touch the JSON files
        Message.saveToFile = false;
        Message.sentCount = 0;
        Message.messageCount = 0;
    }

    // ---------- Message length ----------

    @Test
    public void testMessageLengthSuccess() {
        assertEquals("Message ready to send.", Message.checkMessageLength(MSG1_TEXT));
    }

    @Test
    public void testMessageLengthExactly250Success() {
        String text = "a".repeat(250);
        assertEquals("Message ready to send.", Message.checkMessageLength(text));
    }

    @Test
    public void testMessageLengthFailure() {
        String text = "a".repeat(255); // 5 over the limit
        assertEquals("Message exceeds 250 characters by 5; please reduce the size.",
                Message.checkMessageLength(text));
    }

    // ---------- Recipient number ----------

    @Test
    public void testRecipientNumberSuccess() {
        assertEquals("Cell phone number successfully captured.",
                Message.checkRecipientCell(MSG1_RECIPIENT));
    }

    @Test
    public void testRecipientNumberFailure() {
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                Message.checkRecipientCell(MSG2_RECIPIENT));
    }

    // ---------- Message hash ----------

    @Test
    public void testMessageHashTestCase1() {
        Message msg = new Message("0012345678", MSG1_RECIPIENT, MSG1_TEXT);
        msg.SentMessage("Send");
        assertEquals("00:0:HITONIGHT", msg.getMessageHash());
    }

    @Test
    public void testMessageHashesInLoop() {
        // { id, message number, content, expected hash }
        Object[][] cases = {
            {"0012345678", 0, MSG1_TEXT, "00:0:HITONIGHT"},
            {"0198765432", 1, MSG2_TEXT, "01:1:HIPAYMENT"},
            {"4567890123", 2, "Okay, see you there.", "45:2:OKAYTHERE"},
            {"9900000000", 3, "Thanks", "99:3:THANKSTHANKS"}
        };
        for (Object[] c : cases) {
            String actual = Message.createMessageHash((String) c[0], (Integer) c[1], (String) c[2]);
            assertEquals(c[3], actual);
        }
    }

    // ---------- Message ID ----------

    @Test
    public void testMessageIDCreated() {
        Message msg = new Message(MSG1_RECIPIENT, MSG1_TEXT);
        assertEquals(10, msg.getMessageID().length());
        assertEquals("Message ID generated: " + msg.getMessageID(), msg.messageIDGenerated());
        assertTrue(msg.getMessageID().matches("[0-9]{10}"));
    }

    // ---------- Send / Discard / Store ----------

    @Test
    public void testMessageSentSend() {
        Message msg = new Message(MSG1_RECIPIENT, MSG1_TEXT);
        assertEquals("Message successfully sent.", msg.SentMessage("Send"));
        assertEquals("Sent", msg.getStatus());
    }

    @Test
    public void testMessageSentDiscard() {
        Message msg = new Message(MSG2_RECIPIENT, MSG2_TEXT);
        assertEquals("Press 0 to delete the message.", msg.SentMessage("Discard"));
        assertEquals("Discarded", msg.getStatus());
    }

    @Test
    public void testMessageSentStore() {
        Message msg = new Message(MSG1_RECIPIENT, MSG1_TEXT);
        assertEquals("Message successfully stored.", msg.SentMessage("Store"));
        assertEquals("Stored", msg.getStatus());
    }

    // ---------- Total number sent ----------

    @Test
    public void testTotalNumberSent() {
        Message msg1 = new Message(MSG1_RECIPIENT, MSG1_TEXT);
        msg1.SentMessage("Send");
        Message msg2 = new Message(MSG2_RECIPIENT, MSG2_TEXT);
        msg2.SentMessage("Discard"); // discarded, so it must not count
        assertEquals(1, Message.returnTotalMessages());
    }
}